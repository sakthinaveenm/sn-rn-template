export {default} from './SplashScreen';
