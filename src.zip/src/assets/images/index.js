export const SPLASH_SCREEN_IMG = require('./klogo.png');
export const LOADER_IMG = require('./47-chat-outline.gif');
export const PROFILE_IMG = require('./profile.jpg');
